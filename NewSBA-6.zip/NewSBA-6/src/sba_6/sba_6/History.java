
package sba_6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import sba_6.Inserting.inserting;
import sba_6.Listofoperations.ATM;

public class History implements History1
{
	final static String Reset= "\u001B[0m";
	final static String Purple="\u001B[35m";
	final static String Green= "\u001B[32m";
	public class User_history 
	{
		public static void transactionhistory() 
		{
			Scanner scanner=new Scanner(System.in);
		        System.out.println("---------------------");
		        System.out.println("Transaction History :");
		  
		        if (ATM.balance > 0) 
		        {
		        	inserting.insert();
		        	System.out.println("-------------------------------------------");
			        System.out.println("Do you want Download \033[32mYes\033[0m or \033[31mNo\033[0m");
			        String download = scanner.next();
			        if(download.equalsIgnoreCase("y")) {
			       
			        System.out.println(Green+"SUCCESSFULLY DOWNLOADED"+Reset);
		        }
		        
		        else 
		        {
		            System.out.println("your account is empty");
		        }
		        ATM.select_operation();
		    }
		
	}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void transactionhistory() {
		// TODO Auto-generated method stub
		
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

//
//for (int i = 0; i < (ATM.history.size() / 2); i++) 
//{
//    for (int j = 0; j < 2; j++)
//    {
//        ATM.history.get(k)
//        k++;
//    }
//}
