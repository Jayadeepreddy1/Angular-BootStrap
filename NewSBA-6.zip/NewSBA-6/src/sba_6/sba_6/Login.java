package sba_6;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import sba_6.Listofoperations.ATM;
public class Login implements Login1
{
	final static String RED =  "\033[0;31m";
	final static String Blue = "\u001B[33m";
	final static String Reset= "\u001B[0m";
	final static String Purple="\u001B[35m";
	final static String Green= "\u001B[32m";
	final static String BG= "\u001B[42m";
	final static String Yellow= "\u001B[33m";
	static final String PBG = "\u001B[45m";
	public static final String CYAN = "\u001B[36m";
	final static String BBlack="\u001B[40m";
	final static String White="\u001B[37m";
	
	static void userdetails()
	{
    ArrayList<String> details= new ArrayList<String>();
    details.add("Jayadeep");
    details.add("8639209459");
    details.add("jayadeeptanguturi@gmail.com");
    details.add("Jaya1");
    login(details);
	}
	static void home()
	{
	System.out.println(BBlack+White+" DXC ACCOUNT MANAGEMENT SYSTEM "+Reset);
    System.out.println(Purple+"*****************************"+Reset);
    System.out.println("Select:1 For Login ");
    System.out.println(Purple+"*****************************"+Reset);
    while (true) 
    {
    try 
    {
    Scanner scanner=new Scanner(System.in);
    int Select=scanner.nextInt();
    if(Select==1)
    {
       
         userdetails();
         break;
    }
    else
    {
        System.out.println(RED+"Invalid Input \nEnter Valibe Input"+Reset);
        home();
        break;
       
    }
    }
    catch (InputMismatchException e) 
    {
    	System.out.println(RED+"Enter Correct In-put "+Reset+e);
	}
    }

}
	public static  void login(ArrayList<String>list)
	{
    String name1=list.get(0);
    String mobile1=list.get(1);
    String email1=list.get(2);
    String psw1=list.get(3);
    String psw2;
    Scanner scanner=new Scanner(System.in);
    System.out.println("For login Enter User Name");
    String name=scanner.next();
    System.out.println("Entern Password");
    String psw=scanner.next();
   
    if(name.equals(name1) && psw.equals(psw1))
    {
        System.out.println(Green+"Login Sucessfull"+Reset);
        System.out.println(Purple+"***************************"+Reset);
 //       ATM.select_operation();
    }
    else{
        System.out.println("Forgot User Name & Password : Yes/No");
        char fg=scanner.next().charAt(0);
        if(fg=='y'||fg=='Y'){
            System.out.println("Enter Registered Mobile No/Email_ID");
            String ME=scanner.next();
            if(ME.equals(mobile1)||ME.equals(email1)){
                int min=1000;
                int max=9999;
            	int b = (int)(Math.random()*(max-min+1)+min);
                System.out.println("Auto Generated OTP:"+b);
                System.out.println("Enter OTP");
                int otp=scanner.nextInt();
                while(true)
                {
                if(otp==b)
                {
                    System.out.println("OTP Verified");
                    System.out.println("Create Your Password");
                    psw2=scanner.next();
                    list.set(3,psw2);
                    System.out.println(Green+"Password Reseted Sucessfull"+Reset);
                    System.out.println(Purple+"***************************"+Reset);
                    login(list);
                    break;
                }
                System.out.println(RED+"Invalid OTP"+Reset);
                System.out.println("Enter Valide OTP");
                otp=scanner.nextInt();
            }
            }
            else{
                System.out.println(RED+"Unregisterd Details"+Reset);
               home();
            }
        }
        else{
        login(list);
        }
       
       
    }
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}
}