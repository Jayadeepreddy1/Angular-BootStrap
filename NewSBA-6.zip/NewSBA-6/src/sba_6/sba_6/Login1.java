package sba_6;

public interface Login1 
{
	public void login();
}
