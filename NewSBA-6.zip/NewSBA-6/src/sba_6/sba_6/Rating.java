package sba_6;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Rating 
{
	Scanner sc=new Scanner(System.in);
		Rating() 
		{
			System.out.println("Please rate our Service");
			System.out.println("5-Star");
			System.out.println("4-Star");
			System.out.println("3-Star");
			System.out.println("2-Star");
			System.out.println("1-Star");
			int rating=sc.nextInt();
			switch (rating) 
			{
			case 1: 
			{	
				System.out.print("1-Star :");
				System.out.println("(⭐)");
				System.out.println("Rating");
				System.out.println("Thankyou for your rating");
				break;

				
			}
			case 2: 
			{	
				System.out.print("2-Star :");
				System.out.println("(⭐⭐)");
				System.out.println("Rating");
				System.out.println("bad-Taste");
				System.out.println("Thankyou for your rating");
				break;

			}
			case 3: 
			{	
				System.out.print("3-Star :");
				System.out.println("(⭐⭐⭐⭐)");
				System.out.println("Rating");
				System.out.println("Average-Taste");
				System.out.println("Thankyou for your rating");
				break;

			}
			case 4: 
			{	
				System.out.print("4-Star :");
				System.out.println("(⭐⭐⭐⭐)");
				System.out.println("Rating");
				System.out.println("Good-Taste");
				System.out.println("Thankyou for your rating");
				break;

			}
			case 5: 
			{	
				System.out.print("5-Star :");
				System.out.println("(⭐⭐⭐⭐⭐)");
				System.out.println("Rating");
				System.out.println("Thankyou for your rating");
				break;

			}
			default:
				break;
			}
			
		}
}
