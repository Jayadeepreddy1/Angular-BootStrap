package sba_6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import sba_6.Listofoperations.ATM;

public class Inserting 
{
	final static String RED =  "\033[0;31m";
	final static String Blue = "\u001B[33m";
	final static String Reset= "\u001B[0m";
	final static String Purple="\u001B[35m";
	final static String Green= "\u001B[32m";
	final static String BG= "\u001B[42m";
	final static String Yellow= "\u001B[33m";
	static final String PBG = "\u001B[45m";
	public static final String CYAN = "\u001B[36m";
	final static String BBlack="\u001B[40m";
	final static String White="\u001B[37m";
	public class inserting 
	{
		public static void insert()
		{
		Scanner sc=new Scanner(System.in);
	    try 
	    {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println(Green+"Driver  loader..."+Reset);
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","scott","tiger");
		Statement statement=connection.createStatement();
		System.out.println("-------------------------------------------------------|");
		for (int i = 0; i < ATM.history.size(); i++)
		{
		String balance=ATM.history.get(i);
		String date=ATM.date.get(i);
		String insertQuery="insert into History1 values('"+ balance+"','"+ date+"')";
		int result=statement.executeUpdate(insertQuery);
		}
		
		ResultSet rs=statement.executeQuery("Select * from History1 order by balance asc");
		System.out.println(White+BBlack+"|  Amount   | Type               Date/Time             |");
		System.out.println("-------------------------------------------------------|");
		while (rs.next()!=false) 
		{
			System.out.printf("| %-10s| %-41s| %n",rs.getString(1),rs.getString(2));
		}
		System.out.println("--------------------------------------------------------"+Reset);
		rs.close();
		statement.close();
		connection.close();
	}
	catch (ClassNotFoundException | SQLException e) 
	{
		e.printStackTrace();
	}
}
}
}
