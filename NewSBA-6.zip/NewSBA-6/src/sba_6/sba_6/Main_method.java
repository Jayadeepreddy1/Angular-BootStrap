package sba_6;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sba_6.Check.check;
import sba_6.History.User_history;
import sba_6.Listofoperations.ATM;
import sba_6.Trancation.Transcation;

public class Main_method 
{
		public static void main(String[] args) 
		{
				    Login l=new Login();
     		        l.home();
			        ATM.select_operation();
			        Transcation.withdraw();
			        Transcation.deposit();
			        check.checkbalance();
			        User_history.transactionhistory();
			        Transcation.fixedDeposit();
			        Transcation.Feedback_And_Complaint();
			        Transcation.Exit();

}
}