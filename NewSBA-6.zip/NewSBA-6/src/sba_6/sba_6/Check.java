package sba_6;

import sba_6.Listofoperations.ATM;

public class Check 
{
		public class check
		{
			static void checkbalance() 
			{
			       long b = ATM.display_balance();
			       System.out.println("The available balance in your account is :" + b);
			       System.out.println("-------------------------------------------");
			       
			       ATM.select_operation();
			
			 }

		}
}
