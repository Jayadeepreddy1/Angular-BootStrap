package sba_6;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTable;

import sba_6.Check.check;
import sba_6.History.User_history;
import sba_6.Trancation.Transcation;

public class Listofoperations
{
		final static String RED =  "\033[0;31m";
		final static String CYAN = "\u001B[33m";
		final static String Reset= "\u001B[0m";
		final static String Purple="\u001B[35m";
		final static String Green= "\u001B[32m";
		final static String BG= "\u001B[42m";
		final static String Yellow= "\u001B[33m";
		static final String PBG = "\u001B[45m";
		public static final String BLUE = "\u001B[36m";
		final static String BBlack="\u001B[40m";
		final static String White="\u001B[37m";
		final static String MAGENTA_BOLD="\033[1;35m";
		public static final String BLACK = "\033[0;30m";


		public class ATM 
		{
		   public static String name;
		   public static int choice;
		   public static long ac_no;
		   public static int balance = 200000;
		   public static String account_number;
		   public static long accounts[]= {123456789,987654321,111111111};
		   public static String names[] = {"Jayadeep","Kusuma","Bala"};
		  
		   public static ArrayList<String> history = new ArrayList<String>();
		   public static ArrayList <String> date = new ArrayList<String>();
		   static Scanner scanner = new Scanner(System.in);
		   

		   public static void update_balance(int deposit_cash) 
		   {
		       balance = balance + deposit_cash;
		   }

		   public static int display_balance() 
		   {
		       return balance;
		   }
		 
		static void select_operation() 
		{
			System.out.println(White+"|---------------------------------------|"+Reset);
		    System.out.println(White+BBlack+"|S.NO |      SELECT OPTION              |"+Reset);
		    System.out.println(White+"|---------------------------------------|"+Reset);
		    System.out.printf(Purple+"| %-3s | %-35s | %n", "1.", "Withdraw"+Reset);
		    System.out.printf(RED+"| %-3s | %-35s | %n", "2.", "Deposit"+Reset);
		    System.out.printf(Green+"| %-3s | %-35s | %n", "3.", "Check balance"+Reset);
		    System.out.printf(Purple+"| %-3s | %-35s | %n", "4.", "Transaction History"+Reset);
		    System.out.printf(CYAN+"| %-3s | %-35s | %n", "5.", "Fixed Deposit"+Reset);
		    System.out.printf(BLACK+"| %-3s | %-35s | %n", "6.", "Feedback and Complaint Section"+Reset);
		    System.out.printf("| %-3s | %-47s | %n", "7.",BLUE+"Rating / "+RED+"Exit"+Reset);
		    System.out.println("|---------------------------------------|");
//		    System.out.println(Purple+"1. Withdraw"+Reset);
//		    System.out.println(RED+"2. Deposit"+Reset);
//		    System.out.println(Green+"3. Check balance"+Reset);
//		    System.out.println(Purple+"4. Transaction History"+Reset);
//		    System.out.println(White+"5. Fixed Deposit"+Reset);
//		    System.out.println(BLACK+"6. Mini Statement"+Reset);
//		    System.out.println(CYAN+"7. Feedback and Complaint Section"+Reset);
//		    System.out.println(RED+"8. Exit"+Reset);
		    System.out.print("Enter your choice : ");
		    while(true)
		    {
		    try 
		    {
		    int choice = scanner.nextInt();
		    if(choice==1) 
		    {
		       Transcation.withdraw();
		    }
		    else if(choice==2) 
		    {      
		         Transcation.deposit();
		    }
		    else if(choice==3) 
		    {
		            check.checkbalance();
		    }
		    else if(choice==4) 
		    {
		            User_history.transactionhistory();
		    }
		    else if(choice==5) {
		    

		         Transcation.fixedDeposit();
		    }
		    else if (choice==6) 
		    {
		         Transcation.Feedback_And_Complaint();
		    }
		    
		    else if(choice==7) 
		    {
		         Transcation.Exit();
		    }
		      
		      else
		      {
		      System.out.println("select a value only from the given options ");
		      select_operation();
		      }
		    }
		    catch (InputMismatchException e)
		    {
		     System.out.println(RED+"Invaild "+e+Reset);
		     System.out.println("You have enterd non integer please enter integer input");
		     scanner.next();
		    }
		  }
		      
		}
			
  }



}

