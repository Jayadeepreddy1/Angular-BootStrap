package sba_6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Connectiontest 
{	
	public static void main(String[]args)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver class loader");
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","scott","tiger");
			if (connection==null) 
			{
				System.out.println("Connection not established with Oracle Data Base");
			}
			else 
			{
				System.out.println("Success..Connection is established with Oracle DB");
			}
			Statement statement=connection.createStatement();
			boolean sucess=statement.execute("Create table History1(balance varchar(50), date1 varchar(50))");
			if (sucess==false)
			{
				System.out.println("balance stored in DB..");
			} 
			else 
			{
				System.out.println("Error in table");
			}
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
		
	}
}
