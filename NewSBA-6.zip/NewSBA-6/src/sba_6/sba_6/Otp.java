package sba_6;

import java.util.SplittableRandom;

public class Otp 
{
		public class otpGeneration
		{
		public static String getOTP(final int lengthOfOTP) 
		{
		StringBuilder generatedOTP = new StringBuilder();
		SplittableRandom splittableRandom = new SplittableRandom();

		for (int i = 0; i < lengthOfOTP; i++) {

		int randomNumber = splittableRandom.nextInt(0, 9);
		generatedOTP.append(randomNumber);
		}
		return generatedOTP.toString();
		}
//		int min=1000;
//		int max=9999;
//		int b = (int)(Math.random()*(max-min+1)+min);
//        
		
}
}