package sba_6;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import sba_6.Listofoperations.ATM;
public class Trancation 
{
		public class Transcation extends Otp
		{
			final static String RED =  "\033[0;31m";
			final static String Blue = "\u001B[33m";
			final static String Reset= "\u001B[0m";
			final static String Purple="\u001B[35m";
			final static String Green= "\u001B[32m";
			final static String BG= "\u001B[42m";
			final static String Yellow= "\u001B[33m";
			static final String PBG = "\u001B[45m";
			public static final String CYAN = "\u001B[36m";
			final static String BBlack="\u001B[40m";
			final static String White="\u001B[37m";
			
		    static int account_number,withdraw_cash,deposit_cash,transfered_cash, fixedDespositAmount;
		    static String account;
		    public static int ac_no;
		    public static long accounts[]= {123456789};
		    static Scanner scanner = new Scanner(System.in);

		    public static void deposit() 
		    {
		        Date current_Date = new Date();
		        System.out.println("*************");
		        System.out.println(Purple+"Thanks For Chossing Deposit\n"+Reset);
		        while(true)
		        {
		        System.out.println("Enter the Account_number: ");
		        try 
		        {
		        	 ac_no=scanner.nextInt();
					if (ac_no==accounts[0]) 
					{

					    System.out.print("Enter amount to deposit :");
					    deposit_cash = scanner.nextInt();
					    ATM.update_balance(deposit_cash);

					    ATM.history.add("Rs." + Integer.toString(deposit_cash) + "/-");
					    ATM.date.add("Deposit at " + current_Date);
					    //System.out.println("Amount Rs." + deposit_cash + "/- deposit successful!");
					   
					    System.out.println(White+BBlack+"          Notification              "+Reset);
					    System.out.println("|-----------------------------------------------------------------------------------------------|");          
					    System.out.printf("| %-1s | %2s | %-2s | %-2s | %-2s |%-2s |%-2s |%n", "Dear User", "Your A/c ",ac_no,"Credited by Rs.",deposit_cash," on ",current_Date);
					   // System.out.println("Dear User, Your A/c "+ac_no+" Credited by Rs."+deposit_cash+" on "+current_Date);
					    System.out.println("|-----------------------------------------------------------------------------------------------|\n");
					    System.out.println("****************************");
					    ATM.select_operation();
					    break;
					} 
					else 
					{
						System.out.println(RED+"Please Enter Correct AC-No"+Reset);
					}
					
				}
		        catch (InputMismatchException e) 
		        {
					System.out.println(RED+e+Reset);
					System.out.println("Please enter integer input");
					scanner.next();
				}
		    }	        
}
		   

		    public static void withdraw() 
		    {
		        System.out.println("----------------");
		        while(true)
		        {
		        try {
		        	 System.out.println("Enter the Account_number: ");
		        	 ac_no=scanner.nextInt();
					if (ac_no==accounts[0]) 
					{
					System.out.println("Enter amount for withdraw :");
					withdraw_cash = scanner.nextInt();
					if (withdraw_cash<=25000) 
					{
					if (withdraw_cash <= ATM.balance) 
					{
					    Date current_Date = new Date();
					    ATM.balance = ATM.balance - withdraw_cash;
					    while(true)
					    {
					    String OTP=otpGeneration.getOTP(4);
					    System.out.println("Auto Generated OTP :"+OTP);
					    System.out.print("Enter the OTP :");
					    String otp=scanner.next();
					    try {
							if (OTP.equals(otp)) 
							{
							ATM.history.add("Rs." + Integer.toString(withdraw_cash) + "/-");
							ATM.date.add("Withdraw at " + current_Date);
							System.out.println(White+BBlack+"          Notification              "+Reset);
							System.out.println("|-------------------------------------------------------------------------------------------|");          
							System.out.printf("| %-1s | %2s | %-2s | %-2s | %-2s |%-2s |%-2s |%n", "Dear User", "Your A/c ",ac_no,"Debited Rs.",withdraw_cash," on",current_Date);
							System.out.println("|-------------------------------------------------------------------------------------------|\n");          
							System.out.println("");
							ATM.select_operation();
							break;
}
else 
{
							System.out.println(RED+"Invalide-OTP Please try again"+Reset);
}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					break;
					}
					else 
					{
					    System.out.println("Insufficient money!! you cannot withdraw money from your account!");
					    System.out.println("---------------------------");
					    ATM.select_operation();
					}
					}
					else 
					{
						System.out.println(RED+"Daily Limit is 25000/-(only)"+Reset);
					}
                    }
					else 
					{
						System.out.println(RED+"Enter the correct input"+Reset);
					}
				} 
		        catch (InputMismatchException e) 
		        {
		        	System.out.println(RED+e+Reset);
					System.out.println("Please enter integer input");
					scanner.next();
				}
		        }
		       
		    }
			public static void fixedDeposit()
		    {	
			while(true)
	        {
	        try 
	        {
	        	 System.out.println("Enter the Account_number: ");
	        	  ac_no=scanner.nextInt();
				if (ac_no==accounts[0]) 
				{
						System.out.println("Enter password :");
						while(true)
				        {
					    String pin = scanner.next();
					    if (ac_no==accounts[0]&&pin.equals("jaya1"))
					    {
					    	  Scanner scanner = new Scanner(System.in);
					          
					          System.out.print("Enter the principal amount: ");
					          double principal = scanner.nextDouble();
					          
					          System.out.print("Enter the interest rate (%): ");
					          double interestRate = scanner.nextDouble();
					          
					          System.out.print("Enter the number of years: ");
					          int years = scanner.nextInt();
					          
					          double amount = principal * Math.pow((1 + (interestRate / 100)), years);
					          double interest = amount - principal;
					          
					          System.out.println("Principal Amount: " + principal);
					          System.out.println("Interest Rate: " + interestRate + "%");
					          System.out.println("Number of Years: " + years);
					          System.out.println(Blue+"Total Amount: " + amount+Reset);
					          System.out.println(Green+"Interest Amount: " + interest+Reset); 
					          ATM.select_operation();
					          break;
					    }
					    else 
					    {
					    	System.out.println("Please Enter Correct Password");
					    	
					    }
					    }
				}
					    else 
					    {
					    	System.out.println("Please Enter Correct AC.NO");	
						}
	        }
	        catch (InputMismatchException e) 
	        {
				System.out.println(RED+e+Reset);
				System.out.println("Please enter integer input");
				scanner.next();
			}
	        }
			}
		    public static void MiniStatement()
		    {
		    System.out.println("Enter the account number: ");
		    ac_no= scanner.nextInt();
		    if (ac_no==accounts[0]||ac_no==accounts[1]||ac_no==accounts[2] ) 
		    {
		    System.out.println("***Mini Statement***");
		    System.out.println("-------------------------------------------");
		    System.out.println(" Account No: "+ac_no +" ");
		    System.out.println("-------------------------------------------");
		    int k = 0;
		        if (ATM.balance > 0) 
		        {
		            for (int i = 0; i < (ATM.history.size() / 2); i++) 
		            {
		                for (int j = 0; j < 2; j++) 
		                {
		                    System.out.println(ATM.history.get(k) + " ");
		                    k++;
		                }
		            }
		        }
		        long b = ATM.display_balance();
		        System.out.println("Total Amount: "+b);
		       
		        System.out.println("-------------------------------------------");
		        System.out.println("Do you want Download \033[32mYes\033[0m or \033[31mNo\033[0m");
		        String download = scanner.next();
		        if(download.equalsIgnoreCase("y")) {
		       
		        System.out.println("SUCCESSFULLY DOWNLOADED");
		        ATM.select_operation();

		        }
		        else {
		        ATM.select_operation();
		        }
		           
		}
		   
		}
		public static void Feedback_And_Complaint()
		{
		System.out.println("Feedback and Complaint Section");
		System.out.println("Type your Feedback here");
		String feedback = scanner.next();
		System.out.println("Confirm Yes or No");
		String confirm = scanner.next();
		
		if(confirm.equalsIgnoreCase("Y")) 
		{
		System.out.println("Thanks for Your Feedback");
		}
		else 
		{
		ATM.select_operation();
		}
		System.out.println("Do you have Complaint Yes or No");
		String yes = scanner.next();
		if(yes.equalsIgnoreCase("y")) {
		System.out.println("Type your Complaint here ");
		String complaint = scanner.next();
		} else {
		ATM.select_operation();
		}
		System.out.println("Confirm Yes or No");
		confirm=scanner.next();
		if(confirm.equalsIgnoreCase("y")) {
		System.out.println("Sorry for the inconvenience,we will rectify with in short time");
		ATM.select_operation();
		}
		else {
		ATM.select_operation();
		}
		}
		   
		    public static void Exit()
		    {
		    Rating r=new Rating();
		    System.out.println(Green+"------- Thank you for Visiting DXC Bank!!-------"+Reset);
		    System.exit(0);
		    }
	}

		
}
