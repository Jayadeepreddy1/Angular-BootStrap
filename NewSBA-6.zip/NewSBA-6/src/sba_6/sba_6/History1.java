package sba_6;

public interface History1
{
	public void transactionhistory();
}
